model_type = {
    'ADDRESS': 'address'
}